package com.vubiquity.intellivu.test;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.vubiquity.intellivu.config.Configuration;
import com.vubiquity.intellivu.model.WSTestCaseTemplate;
import com.vubiquity.intellivu.processor.IVUWSProcessor;
import com.vubiquity.intellivu.processor.TestCaseProcessor;
import com.vubiquity.intellivu.util.FileUtil;

public class WebServiceTest {

    private String testCaseLocation;
    private String webserviceEndPoint;

    @Test
    public void f() {
        List<String> fileNames = FileUtil.listFiles(testCaseLocation);
        ExecutorService executorService = Executors.newFixedThreadPool(fileNames.size());
        for (String fileName : fileNames) {
            runTest(fileName);
//            executorService.execute(() -> runTest(fileName));
        }

        executorService.shutdown();
        while (!executorService.isTerminated()) {
        }
    }

    public void runTest(String fileName) {
        TestCaseProcessor processor = new TestCaseProcessor(testCaseLocation + fileName);
        List<WSTestCaseTemplate> testCases = processor.getWSTestCaseTemplateFromExcel();
        IVUWSProcessor.runTest(testCases, webserviceEndPoint);
        processor.writeWSTestResultToExcel(testCases);
    }

    @BeforeClass
    public void beforeClass() {
        testCaseLocation = Configuration.getInstance().getTestCaseLocation() + "ws\\";
        webserviceEndPoint = Configuration.getInstance().getWebServiceEndPoint();
    }

}
