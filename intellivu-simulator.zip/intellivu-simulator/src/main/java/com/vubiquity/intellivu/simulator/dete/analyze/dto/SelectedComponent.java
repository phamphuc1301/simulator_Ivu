package com.vubiquity.intellivu.simulator.dete.analyze.dto;

public class SelectedComponent {
	private Long id;
	private String status;
	private String qcStatus;
	private String assocStatus;
	
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getQcStatus() {
		return qcStatus;
	}
	public void setQcStatus(String qcStatus) {
		this.qcStatus = qcStatus;
	}
	public String getAssocStatus() {
		return assocStatus;
	}
	public void setAssocStatus(String assocStatus) {
		this.assocStatus = assocStatus;
	}
	
	
}
