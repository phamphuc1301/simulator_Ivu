package com.vubiquity.intellivu.simulator.adoniss.service;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.vubiquity.intellivu.simulator.adoniss.dto.AAPIGetMediaManagerProviderPackageTierResult;
import com.vubiquity.intellivu.simulator.adoniss.dto.GetAAPIHeadendsOnProfileDetails;
import com.vubiquity.intellivu.util.JsonUlti;

@RestController
public class AdonissRESTService {

    
    
    @RequestMapping(method = RequestMethod.GET, value = "/Adoniss.RESTServices/AdonissRESTService/GetMediaManagerProviderPackageTier")
    @ResponseBody
    public AAPIGetMediaManagerProviderPackageTierResult[] getMediaManagerProviderPackageTier() {
        String json = "[{\"Finance_codec\":\"SD-2\",\"MediaManager\":null,\"c_codecs\":\"MPEG-2\",\"c_contentpackage\":\"A&E_BIOGRAPHY_10\",\"c_contentparentcompany\":\"A&E\",\"c_contentprovideronDST\":\"A&E\",\"c_contenttier\":\"A&E_BIOGRAPHY_10\",\"c_video_format\":\"\",\"dt_activated_package\":\"Oct  1 2002 12:00AM\",\"dt_activated_provider\":\"Oct  1 2002 12:00AM\",\"dt_activated_tier\":\"Oct  1 2002 12:00AM\",\"dt_deactivated_package\":\"May 25 2006  9:46AM\",\"dt_deactivated_provider\":\"Sep 12 2008 11:25AM\",\"dt_deactivated_tier\":\"May 25 2006  9:46AM\",\"i_contenttierhrs\":10,\"id_adonissuser\":null,\"id_adonissuserfunction_adonissuser\":null,\"id_contentpackages\":1,\"id_contentparentcompany\":1,\"id_contentprovider\":1,\"id_contenttiers\":1,\"id_contenttiersparent\":null},{\"Finance_codec\":\"SD-2\",\"MediaManager\":null,\"c_codecs\":\"MPEG-2\",\"c_contentpackage\":\"A&E_HISTORY_10\",\"c_contentparentcompany\":\"A&E\",\"c_contentprovideronDST\":\"A&E\",\"c_contenttier\":\"A&E_HISTORY_10\",\"c_video_format\":\"\",\"dt_activated_package\":\"Oct  1 2002 12:00AM\",\"dt_activated_provider\":\"Oct  1 2002 12:00AM\",\"dt_activated_tier\":\"Oct  1 2002 12:00AM\",\"dt_deactivated_package\":\"May 25 2006  9:47AM\",\"dt_deactivated_provider\":\"Sep 12 2008 11:25AM\",\"dt_deactivated_tier\":\"May 25 2006  9:47AM\",\"i_contenttierhrs\":10,\"id_adonissuser\":null,\"id_adonissuserfunction_adonissuser\":null,\"id_contentpackages\":2,\"id_contentparentcompany\":1,\"id_contentprovider\":1,\"id_contenttiers\":2,\"id_contenttiersparent\":null},{\"Finance_codec\":\"SD-2\",\"MediaManager\":null,\"c_codecs\":\"MPEG-2\",\"c_contentpackage\":\"A&E_NETWORK_10\",\"c_contentparentcompany\":\"A&E\",\"c_contentprovideronDST\":\"A&E\",\"c_contenttier\":\"A&E_NETWORK_10\",\"c_video_format\":\"\",\"dt_activated_package\":\"Oct  1 2002 12:00AM\",\"dt_activated_provider\":\"Oct  1 2002 12:00AM\",\"dt_activated_tier\":\"Oct  1 2002 12:00AM\",\"dt_deactivated_package\":\"May 25 2006  9:48AM\",\"dt_deactivated_provider\":\"Sep 12 2008 11:25AM\",\"dt_deactivated_tier\":\"May 25 2006  9:48AM\",\"i_contenttierhrs\":10,\"id_adonissuser\":null,\"id_adonissuserfunction_adonissuser\":null,\"id_contentpackages\":3,\"id_contentparentcompany\":1,\"id_contentprovider\":1,\"id_contenttiers\":3,\"id_contenttiersparent\":null}]";
        return (AAPIGetMediaManagerProviderPackageTierResult[]) JsonUlti.jsonStringToObject(json, AAPIGetMediaManagerProviderPackageTierResult[].class);
    }

    @RequestMapping(method = RequestMethod.GET, value = "/Adoniss.RESTServices/AdonissRESTService/GetAAPIHeadendsOnProfileDetails/{id}/{date}")
    @ResponseBody
    public GetAAPIHeadendsOnProfileDetails[] getAllMsoHeadendByProvider(@PathVariable Integer id, @PathVariable String date) {
        String json = "[{\"c_headendname\":\"Comcast - NETO Lab Denver, CO\",\"c_msoname\":\"Comcast Cable Communications\",\"id_contenttiers\":4851,\"id_headends\":679,\"id_msos\":3},{\"c_headendname\":\"Comcast - NETO Lab Denver, CO\",\"c_msoname\":\"Comcast Cable Communications\",\"id_contenttiers\":5489,\"id_headends\":795,\"id_msos\":3},{\"c_headendname\":\"Comcast - NETO Lab Denver, CO\",\"c_msoname\":\"Comcast Cable Communications\",\"id_contenttiers\":5492,\"id_headends\":698,\"id_msos\":3}]";
        return (GetAAPIHeadendsOnProfileDetails[]) JsonUlti.jsonStringToObject(json, GetAAPIHeadendsOnProfileDetails[].class);
    }
    
}
