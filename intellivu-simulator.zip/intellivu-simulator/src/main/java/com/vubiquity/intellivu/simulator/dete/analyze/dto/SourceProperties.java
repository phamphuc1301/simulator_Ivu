package com.vubiquity.intellivu.simulator.dete.analyze.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SourceProperties {
	private String standard;
	private String frameAspectRatio;
	private String language;
	private String content;
	private String trackConfiguration;
	private String format;
	private String textType;
	private String none;
	private String all;

	public String getStandard() {
		return standard;
	}

	public void setStandard(String standard) {
		this.standard = standard;
	}

	public String getFrameAspectRatio() {
		return frameAspectRatio;
	}

	public void setFrameAspectRatio(String frameAspectRatio) {
		this.frameAspectRatio = frameAspectRatio;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getTrackConfiguration() {
		return trackConfiguration;
	}

	public void setTrackConfiguration(String trackConfiguration) {
		this.trackConfiguration = trackConfiguration;
	}

	public String getFormat() {
		return format;
	}

	public void setFormat(String format) {
		this.format = format;
	}

	public String getTextType() {
		return textType;
	}

	public void setTextType(String textType) {
		this.textType = textType;
	}

	@JsonProperty("[NONE]")
    public String getNone() {
        return none;
    }

	@JsonProperty("[NONE]")
    public void setNone(String none) {
        this.none = none;
    }

	@JsonProperty("[ALL]")
    public String getAll() {
        return all;
    }

	@JsonProperty("[ALL]")
    public void setAll(String all) {
        this.all = all;
    }
}
