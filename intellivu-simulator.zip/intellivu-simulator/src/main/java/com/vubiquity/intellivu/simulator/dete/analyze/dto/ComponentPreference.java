package com.vubiquity.intellivu.simulator.dete.analyze.dto;

import java.util.List;
import java.util.Set;

public class ComponentPreference {
	private List<ComponentPreferenceValue> componentPreferenceValues;
	private Set<String> componentPreferenceHeaders;

	public List<ComponentPreferenceValue> getComponentPreferenceValues() {
		return componentPreferenceValues;
	}

	public void setComponentPreferenceValues(List<ComponentPreferenceValue> componentPreferenceValues) {
		this.componentPreferenceValues = componentPreferenceValues;
	}

	public Set<String> getComponentPreferenceHeaders() {
		return componentPreferenceHeaders;
	}

	public void setComponentPreferenceHeaders(Set<String> componentPreferenceHeaders) {
		this.componentPreferenceHeaders = componentPreferenceHeaders;
	}
}
