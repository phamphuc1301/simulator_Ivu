package com.vubiquity.intellivu.simulator.dete.analyze.dto;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class RecipientPreferenceByFormatSheet {

    private List<String> formatSheetId;

    private String outputTemplateName;

    private RecipientPreferenceByComponentType recipientPreferenceByComponentType;

    public List<String> getFormatSheetId() {
        return formatSheetId;
    }

    public void setFormatSheetId(List<String> formatSheetId) {
        this.formatSheetId = formatSheetId;
    }

    public String getOutputTemplateName() {
        return outputTemplateName;
    }

    public void setOutputTemplateName(String outputTemplateName) {
        this.outputTemplateName = outputTemplateName;
    }

    public RecipientPreferenceByComponentType getRecipientPreferenceByComponentType() {
        return recipientPreferenceByComponentType;
    }

    public void setRecipientPreferenceByComponentType(RecipientPreferenceByComponentType recipientPreferenceByComponentType) {
        this.recipientPreferenceByComponentType = recipientPreferenceByComponentType;
    }

}
