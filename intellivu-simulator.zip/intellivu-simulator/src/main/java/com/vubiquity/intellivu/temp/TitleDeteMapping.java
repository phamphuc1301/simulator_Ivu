//package com.vubiquity.intellivu.temp;
//
//import java.util.List;
//
//import org.apache.commons.lang3.StringUtils;
//
//import com.vubiquity.intellivu.util.ExcelUtil;
//
//public class TitleDeteMapping {
//    public static void main(String[] args) {
//        List<List<String>> results = ExcelUtil.readExcel("C:\\Users\\anhdh5\\Desktop\\adoniss-reference.xlsx");
//
//        for (List<String> row : results) {
//            if (StringUtils.isNotBlank(row.get(6))) {
//                System.out.println(updateSQL(row));
//            }
//        }
//    }
//
//    private static String updateSQL(List<String> row) {
//        String template = "insert into adoniss_reference (id_object, c_object, c_type_object, id_assettype, id_assetsubtype, c_subtype, ivu_field) values (" + row.get(0) + ",'" + row.get(1) + "'" + ",'"
//                + row.get(2) + "'," + row.get(3) +","+ row.get(4) + ",'" + row.get(5) + "'" + ",'" + row.get(6) + "'" + ");";
//        return template;
//    }
//}
