package com.vubiquity.intellivu.simulator.dete.analyze.dto;

import java.util.Set;

public class ComponentByFormatSheet {
	private Set<String> formatSheetId;
	private ComponentPreference videoPreference;
	private ComponentPreference audioPreference;
	private ComponentPreference closedCaptioningPreference;
	private ComponentPreference subTitlePreference;

	public Set<String> getFormatSheetId() {
		return formatSheetId;
	}

	public void setFormatSheetId(Set<String> formatSheetId) {
		this.formatSheetId = formatSheetId;
	}

	public ComponentPreference getVideoPreference() {
		return videoPreference;
	}

	public void setVideoPreference(ComponentPreference videoPreference) {
		this.videoPreference = videoPreference;
	}

	public ComponentPreference getAudioPreference() {
		return audioPreference;
	}

	public void setAudioPreference(ComponentPreference audioPreference) {
		this.audioPreference = audioPreference;
	}

	public ComponentPreference getClosedCaptioningPreference() {
		return closedCaptioningPreference;
	}

	public void setClosedCaptioningPreference(ComponentPreference closedCaptioningPreference) {
		this.closedCaptioningPreference = closedCaptioningPreference;
	}

	public ComponentPreference getSubTitlePreference() {
		return subTitlePreference;
	}

	public void setSubTitlePreference(ComponentPreference subTitlePreference) {
		this.subTitlePreference = subTitlePreference;
	}

}
