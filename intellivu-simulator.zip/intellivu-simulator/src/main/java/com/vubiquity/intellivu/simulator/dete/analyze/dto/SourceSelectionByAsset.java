package com.vubiquity.intellivu.simulator.dete.analyze.dto;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonIgnore;


@Document(collection = "source_selection_by_asset")
public class SourceSelectionByAsset {
    
    @JsonIgnore
    @Id
    private String id;// key = assetId_tenant_recipientId
    
	private String assetId;

	private List<SourceSelectionByFormatSheet> sourceSelectionByFormatSheet;

	public String getAssetId() {
		return assetId;
	}

	public void setAssetId(String assetId) {
		this.assetId = assetId;
	}

	public List<SourceSelectionByFormatSheet> getSourceSelectionByFormatSheet() {
		return sourceSelectionByFormatSheet;
	}

	public void setSourceSelectionByFormatSheet(List<SourceSelectionByFormatSheet> sourceSelectionByFormatSheet) {
		this.sourceSelectionByFormatSheet = sourceSelectionByFormatSheet;
	}

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

}
