package com.vubiquity.intellivu.simulator.dete.analyze.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SourceSelectionByComponentType {
    @JsonProperty("VideoComponent")
	private List<Component> videoComponent;
    @JsonProperty("AudioConfigurationComponent")
	private List<Component> audioConfigurationComponent;
    @JsonProperty("ClosedCaptionComponent")
	private List<Component> closedCaptionComponent;
    @JsonProperty("SubtitleComponent")
	private List<Component> subtitleComponent;

	public List<Component> getVideoComponent() {
		return videoComponent;
	}

	public void setVideoComponent(List<Component> videoComponent) {
		this.videoComponent = videoComponent;
	}

	public List<Component> getAudioConfigurationComponent() {
		return audioConfigurationComponent;
	}

	public void setAudioConfigurationComponent(List<Component> audioConfigurationComponent) {
		this.audioConfigurationComponent = audioConfigurationComponent;
	}

	public List<Component> getClosedCaptionComponent() {
		return closedCaptionComponent;
	}

	public void setClosedCaptionComponent(List<Component> closedCaptionComponent) {
		this.closedCaptionComponent = closedCaptionComponent;
	}

	public List<Component> getSubtitleComponent() {
		return subtitleComponent;
	}

	public void setSubtitleComponent(List<Component> subtitleComponent) {
		this.subtitleComponent = subtitleComponent;
	}

}
