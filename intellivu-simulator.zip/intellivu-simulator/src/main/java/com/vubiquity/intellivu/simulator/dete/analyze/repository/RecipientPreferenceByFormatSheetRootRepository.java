package com.vubiquity.intellivu.simulator.dete.analyze.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.vubiquity.intellivu.simulator.dete.analyze.dto.RecipientPreferenceByFormatSheetRoot;

public interface RecipientPreferenceByFormatSheetRootRepository extends MongoRepository<RecipientPreferenceByFormatSheetRoot, String> {

}
