package com.vubiquity.intellivu.processor;

public class DBConstant {
    public static final String DB_DRIVER = "org.postgresql.Driver";
    public static final String DB_CONNECTION = "jdbc:postgresql://10.17.74.85:5432/intelivu_2";
    public static final String DB_USER = "postgres";
    public static final String DB_PASSWORD = "123456";
}
