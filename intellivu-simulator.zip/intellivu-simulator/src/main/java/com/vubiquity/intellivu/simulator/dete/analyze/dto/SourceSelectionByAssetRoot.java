package com.vubiquity.intellivu.simulator.dete.analyze.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SourceSelectionByAssetRoot {
    
	private List<SourceSelectionByAsset> sourceSelectionByAsset;
	
    public SourceSelectionByAssetRoot() {
        
    }
    
    public SourceSelectionByAssetRoot(List<SourceSelectionByAsset> sourceSelectionByAsset) {
        this.sourceSelectionByAsset = sourceSelectionByAsset;
    } 

	public List<SourceSelectionByAsset> getSourceSelectionByAsset() {
		return sourceSelectionByAsset;
	}
}
