package com.vubiquity.intellivu.simulator.dete.analyze.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class RecipientPreferenceByComponentType {
	private List<MissingComponent> videoComponent;
	private List<MissingComponent> audioConfigurationComponent;
	private List<MissingComponent> closedCaptionComponent;
	private List<MissingComponent> subtitleComponent;

	@JsonProperty("VideoComponent")
	public List<MissingComponent> getVideoComponent() {
		return videoComponent;
	}

	public void setVideoComponent(List<MissingComponent> videoComponent) {
		this.videoComponent = videoComponent;
	}

	@JsonProperty("AudioConfigurationComponent")
	public List<MissingComponent> getAudioConfigurationComponent() {
		return audioConfigurationComponent;
	}

	public void setAudioConfigurationComponent(List<MissingComponent> audioConfigurationComponent) {
		this.audioConfigurationComponent = audioConfigurationComponent;
	}

	@JsonProperty("ClosedCaptionComponent")
	public List<MissingComponent> getClosedCaptionComponent() {
		return closedCaptionComponent;
	}

	public void setClosedCaptionComponent(List<MissingComponent> closedCaptionComponent) {
		this.closedCaptionComponent = closedCaptionComponent;
	}

	@JsonProperty("SubtitleComponent")
	public List<MissingComponent> getSubtitleComponent() {
		return subtitleComponent;
	}

	public void setSubtitleComponent(List<MissingComponent> subtitleComponent) {
		this.subtitleComponent = subtitleComponent;
	}

}
