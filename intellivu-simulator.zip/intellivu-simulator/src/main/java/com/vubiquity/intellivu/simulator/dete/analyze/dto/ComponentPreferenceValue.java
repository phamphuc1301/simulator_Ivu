package com.vubiquity.intellivu.simulator.dete.analyze.dto;

import java.util.ArrayList;
import java.util.List;

public class ComponentPreferenceValue {
	private String preference;
	private List<SourceProperties> sourceProperties;

	public String getPreference() {
		return preference;
	}

	public void setPreference(String preference) {
		this.preference = preference;
	}

	public List<SourceProperties> getSourceProperties() {
		if (sourceProperties == null) {
			sourceProperties = new ArrayList<>();
		}
		return sourceProperties;
	}

	public void setSourceProperties(List<SourceProperties> sourceProperties) {
		this.sourceProperties = sourceProperties;
	}
}
