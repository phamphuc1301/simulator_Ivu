package z8.art.keywords;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import z8.art.common.Constants;
import z8.art.common.Global;
import z8.art.dto.MediaOrderDetailDto;
import z8.art.dto.MediaOrderDto;
import z8.art.dto.ProjectDto;
import z8.art.dto.RecipientDto;
import z8.art.dto.SourceAsset;
import z8.art.dto.TitleDto;
import z8.art.object.KeywordInfo;
import z8.art.service.MediaOrderService;
import z8.art.service.MpOrderService;
import z8.art.service.ProjectService;
import z8.art.service.RecipientService;
import z8.art.service.SourceAssetService;
import z8.art.service.TittleService;
import z8.art.util.GenerateString;
import z8.art.util.ReadFileUtil;
import z8.art.util.SOAPClientSAAJ;

public class CreateNewOrder extends ProviderPage {

	private static final Logger LOGGER = Logger.getLogger(CreateNewOrder.class);
	private RecipientService recipientService = new RecipientService();
	private ProjectService projectService = new ProjectService();
	private TittleService titleService = new TittleService();
	private MediaOrderService mediaOrderService = new MediaOrderService();
	private MpOrderService mpOrderService = new MpOrderService();

	public String orderName = "";
	public String po = "";
	public String note = "";
	public static String ipTitleId = "";
	public static String ipTitle = "";
	public String numberGenerate;
	private String dateCompare;
	private String sourceType = "";
	private String releaseType = "";
	private int CHECK_LINK_WO_NOSEQ_FIRST_BY_UI = 1;
	private int CHECK_LINK_WO_NOSEQ_SECOND_BY_UI = 0;
	public int TWO_ROW_MP_ORDER_ID_DELIVERY_ORDER = 1;
	public int TWO_ROW_MP_ORDER_ID_INGEST_ORDER = 0;
	public int ONE_ROW_MP_ORDER_ID_DELIVERY_ORDER = 0;
	public String TEXT_PO_CASE_9 = "TEST09 PO";

	private List<ProjectDto> listOfProjectFromDB = new ArrayList<ProjectDto>();
	private List<MediaOrderDetailDto> listOfMediaOrderDetail = new ArrayList<MediaOrderDetailDto>();

	@KeywordInfo(Description = "Mock data for each testcases", Priority = CRI_SCENARIO)
	public void mockData() {
		// mock title for test cases is not impact
		if (isRequired("Check mock title")) {
			LOGGER.info("START MOCK TITLE FOR THIS TEST CASE!");
			mockTitle();
			LOGGER.info("FINISH MOCK TITLE FOR THIS TEST CASE!");
		}
		LOGGER.info("START MOCK DATA FOR TAB 4 AND ANALYZE SOURCE!");
		MockDataForSubmitOrder mock = new MockDataForSubmitOrder();
		// mock data for tab 4
		switch (getDataText("Mock Data")) {
		case Constants.AWAITING_INGEST:
			mock.mockAwaitingIngestOrIngested(MockDataForSubmitOrder.ipTitleId,
					Constants.AWAITING_INGEST_FILE, getDataText("Tenant"),
					getDataText("RecipientID"));
			break;
		case Constants.INGESTED:
			mock.mockAwaitingIngestOrIngested(MockDataForSubmitOrder.ipTitleId,
					Constants.INGESTED_FILE, getDataText("Tenant"),
					getDataText("RecipientID"));
			break;
		case Constants.AWAITING_INGEST_MISSING:
			mock.mockAwaitingIngestOrIngested(MockDataForSubmitOrder.ipTitleId,
					Constants.AWAITING_INGEST_MISSING_FILE,
					getDataText("Tenant"), getDataText("RecipientID"));
			break;
		case Constants.AWAITING_INGEST_INGESTED:
			mock.mockAwaitingIngestOrIngested(MockDataForSubmitOrder.ipTitleId,
					Constants.AWAITING_INGEST_INGESTED_FILE,
					getDataText("Tenant"), getDataText("RecipientID"));
			break;
		case Constants.INGESTED_MISSING:
			mock.mockAwaitingIngestOrIngested(MockDataForSubmitOrder.ipTitleId,
					Constants.INGESTED_MISSING_FILE, getDataText("Tenant"),
					getDataText("RecipientID"));
			break;
		default:
			break;
		}

		// mock data for analyze source
		if (isRequired("Mock data for analyze source")) {
			MockDataForSubmitOrder dataForSubmitOrder = new MockDataForSubmitOrder();
			String entity = ReadFileUtil
					.readFile(Constants.MOCK_ANALYZE_SOURCE_FILE);
			dataForSubmitOrder.mockDataForRecipientPreferences(entity,
					getDataText("Tenant"), getDataText("RecipientID"));
			LOGGER.info("FINISH MOCK DATA FOR TAB 4 AND ANALYZE SOURCE!");
		}

	}

	@KeywordInfo(Description = "Verify value default on Order Detail tab", Priority = CRI_SCENARIO)
	public void verifyValueDefaultOrderDetails() {
		LOGGER.info("Start verify data on Order Tab !");
		wait(5);
		if (isRequired("Check value default of Type")) {
			myClick("OrderDetails.Type.Dropdown");
			wait(Constants.WAIT_2_SECOND);
			compareTextFullReport(getText("OrderDetails.Type.Dropdown"),
					getDataText("Check value default of Type"));
		}
		if (isRequired("Check value default of Studio")) {
			wait(Constants.WAIT_2_SECOND);
			myClick("OrderDetails.Studio.Dropdown");
			wait(Constants.WAIT_2_SECOND);
			compareTextFullReport(getText("OrderDetails.Studio.Dropdown"),
					getDataText("Check value default of Studio"));
		}

		if (isRequired("Check value default of Due Date and Start Date")) {
			DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
			Date date = new Date();
			dateCompare = dateFormat.format(date);
			compareTextFullReport(getText("OrderDetails.DueDate.DatePick"),
					dateCompare);
			compareTextFullReport(getText("OrderDetails.StartDate.DatePick"),
					dateCompare);
		}
	}

	@KeywordInfo(Description = "Input data on Order Details")
	public void inputDataOrderDetails() {
		LOGGER.info("Input data required on Order Tab !");
		Date date = new Date();
		numberGenerate = " " + date.getTime();
		orderName = getDataText("Input data Order Name") + numberGenerate;
		po = getDataText("Input data PO") + numberGenerate;
		note = getDataText("Input data Note") + numberGenerate;

		if (isRequired("Input data Order Name")) {
			wait(Constants.WAIT_1_SECOND);
			mySendKey("OrderDetails.OrderName.Input", orderName);
		}
		if (isRequired("Input data PO")) {
			wait(Constants.WAIT_1_SECOND);
			mySendKey("OrderDetails.PO.Input", po);
		}

		if (isRequired("Is Ingest Only")) {
			myClick("OrderDetails.Type.Dropdown");
			wait(Constants.WAIT_1_SECOND);
			myClick("OrderDetails.Type.IngestOnly.Dropdown");
		}

		if (isRequired("Compare list Receipient UI with List Project Database")) {
			List<String> listOfNameRecipientFromUI = getElementOfListFromUI("OrderDetails.Receipient.Span.Dropdown");
			List<String> listOfNameRecipientFromDB = getListRecipientName();
			if (isRequired("Is Ingest Only")) {
				checkListEqualRecipient(listOfNameRecipientFromUI,
						listOfNameRecipientFromDB, false);
			} else {
				checkListEqualRecipient(listOfNameRecipientFromUI,
						listOfNameRecipientFromDB, true);
			}
		}

		myClick("OrderDetails.Receipient.Button");
		myClick(buildObjPathByFieldNames("OrderDetails.Receipient.Dropdown",
				"Select element of Receipient"));

		if (isRequired("Compare list Project UI with List Project Database")) {
			compareListProjectAndSelectProject();
		}

		if (isRequired("Input data Note")) {
			myClick("OrderDetails.Note.Input");
			mySendKey("OrderDetails.Note.Input", note);
		}

		if (isRequired("Click Next Button in Order Detail Tab")) {
			myClick("CreateNewOrder.Common.NextTab.Button");
			wait(Constants.WAIT_2_SECOND);
		}
	}

	@KeywordInfo(Description = "Actions on Select Title", Priority = CRI_SCENARIO)
	public void actionsOnSelectTitle() {
		LOGGER.info("Actions on Select Title");
		if (isRequired("Compare default limit record on one page")) {
			compareTextFullReport(
					getText("SelectTitle.DefaultLimitRecord.Dropdown"),
					getDataText("Compare default limit record on one page"));
		}

		if (isRequired("Check Show selected")) {
			checkNotSelected("SelectTitle.ShowSelected.CheckBox");
		}

		if (isRequired("Check type list dropdown Title tab")) {
			List<String> listOfType = new ArrayList<String>();
			List<TitleDto> listOfDTO = titleService.findAllType();
			for (TitleDto titleDto : listOfDTO) {
				listOfType.add(titleDto.getType());
			}
			checkValueListDropdownCommon("SelectTitle.Type.Dropdown",
					"SelectTitle.Type.Dropdown.Option", listOfType);
			wait(Constants.WAIT_1_SECOND);
			myClick("SelectTitle.Background");
			wait(Constants.WAIT_2_SECOND);
		}

		if (isRequired("Add Titles button")) {
			addNewTitle();
			wait(Constants.WAIT_1_SECOND);
			compareTextFullReport(getText("SelectTitle.ValueOfIpTitleIntable"),
					ipTitleId);
		}

		if (isRequired("Search By Titles")) {
			mySendKey("SelectTitle.SearchByTitle.Input",
					MockDataForSubmitOrder.ipTitle);
			wait(Constants.WAIT_1_SECOND);
			myClick("SelectTitle.Search.Button");
			wait(Constants.WAIT_2_SECOND);
		}

		if (isRequired("Compare and select title after search")) {
			compareTextFullReport(getText("SelectTitle.ValueOfIpTitleIntable"),
					MockDataForSubmitOrder.ipTitleId);
			wait(Constants.WAIT_1_SECOND);
			myClick("SelectTitle.ResultIntable.CheckBox");
			wait(Constants.WAIT_1_SECOND);

		}

		if (isRequired("Click Next Button in Select Title Tab")) {
			wait(Constants.WAIT_1_SECOND);
			myClick("CreateNewOrder.Common.NextTab.Button");

		}
	}

	@KeywordInfo(Description = "Actions on Sources tab", Priority = CRI_SCENARIO)
	public void actionsOnSourcesTab() {
		LOGGER.info("Actions on Sources tab");
		wait(Constants.WAIT_10_SECOND);
		if (isRequired("Check value Asset Type")) {
			wait(Constants.WAIT_2_SECOND);
			compareTextFullReport(getText("Sources.AssetType"),
					getDataText("Check value Asset Type"));
		}
		wait(Constants.WAIT_2_SECOND);
		if (isRequired("Check value Edit Version")) {
			compareTextFullReport(getText("Sources.EditVersion"),
					getDataText("Check value Edit Version"));
		}
		wait(Constants.WAIT_2_SECOND);
		if (isRequired("Check value Process Type")) {
			compareTextFullReport(getText("Sources.ProcessType"),
					getDataText("Check value Process Type"));
		}
		wait(Constants.WAIT_2_SECOND);
		if (isRequired("Check value Matte Style")) {
			compareTextFullReport(getText("Sources.MatteStyle"),
					getDataText("Check value Matte Style"));
		}
		wait(Constants.WAIT_2_SECOND);
		if (isRequired("Check value Texted Type")) {
			compareTextFullReport(getText("Sources.TextedType"),
					getDataText("Check value Texted Type"));
		}
		wait(Constants.WAIT_2_SECOND);
		if (isRequired("Check value Content Type")) {
			compareTextFullReport(getText("Sources.ContentType"),
					getDataText("Check value Content Type"));
		}
		wait(Constants.WAIT_2_SECOND);
		if (isRequired("Verify value in result sources tab")) {
			checkExist("Sources.ValueOfIpTitleIntable");
		}
		wait(Constants.WAIT_2_SECOND);

		if (isRequired("Click Next Button in Sources Tab")) {
			wait(Constants.WAIT_1_SECOND);
			myClick("CreateNewOrder.Common.NextTab.Button");
			wait(Constants.WAIT_1_SECOND);
		}
	}

	@KeywordInfo(Description = "Actions on Preferences tab", Priority = CRI_SCENARIO)
	public void actionsOnPreferencesTab() {
		LOGGER.info("Actions on Preferences tab");
		wait(Constants.WAIT_5_SECOND);
		checkValueFilterComponentOnPreferencesTab();

		wait(Constants.WAIT_5_SECOND);
		switch (getDataText("Select Sourse")) {
		case Constants.AWAITING_INGEST:
			myClick("Preferences.Checked.Awaiting_Ingest");
			break;
		case Constants.INGESTED:
			myClick("Preferences.Checked.Ingested");
			break;
		case Constants.MISSING:
			myClick("Preferences.Table.Title.Missing");
			LOGGER.info("WAITING ANALYZE SOURCE OPEN...");
			wait(Constants.WAIT_5_SECOND);
			break;
		case Constants.INGEST_ONLY:
			myClick("Preferences.Table.Title.Missing");
			LOGGER.info("WAITING ANALYZE SOURCE OPEN...");
			wait(Constants.WAIT_5_SECOND);
			break;
		case Constants.AWAITING_INGEST_INGESTED:
			myClick("Preferences.Table.Title.Missing-Row.Row2");
			break;
		default:
			myClick("Preferences.Table.Title.Invalid-Row.Row2");
			break;
		}
	}

	@KeywordInfo(Description = "Actions in Analyze Source", Priority = CRI_SCENARIO)
	public void actionsInAnalyzeSource() {
		wait(Constants.WAIT_10_SECOND);
		actionsInVideoTab();
		if (isRequired("Pre-Oder Information Tab")) {
			addNewRow();
		}
		actionsInAudioTab();
		actionsInCCTab();
		actionsInSubtitleTab();
		if (isRequired("Click update in Analyze Source")) {
			myClick("Analyze.Source.Button.Update");
		}
	}

	@KeywordInfo(Description = "Actions in list of source", Priority = CRI_SCENARIO)
	public void actionsInListOfSource() {
		compareValueInLOS();
		if (isRequired("Add another source")) {
			addNewRowInLOS();
		}

		clickSourceLinkGoToSSS();

		if (isRequired("Click Save SSS button")) {
			wait(Constants.WAIT_2_SECOND);
			myClick("SSS.Save.Button");
		}

		if (isRequired("Click button save in Pre Information")) {
			wait(Constants.WAIT_5_SECOND);
			myClick("LOS.Button.Save");
			wait(Constants.WAIT_1_SECOND);
		}
		wait(Constants.WAIT_1_SECOND);

		if (isRequired("Click Next Button in Preferences Tab")) {
			wait(Constants.WAIT_5_SECOND);
			myClick("CreateNewOrder.Common.NextTab.Button");
			wait(Constants.WAIT_5_SECOND);
			checkExist("Message_CreateSuccess");
			wait(Integer.valueOf(getDataText("Wait After Submited")));
		}

	}

	@KeywordInfo(Description = "Check submited order in Pre Order Tab and Submited Tab", Priority = CRI_SCENARIO)
	public void checkSubmitedOnUI() {
		LOGGER.info("Check submited order in Pre Order Tab and Submited Tab !");
		String status = "";
		if (isRequired("Pre-Order Tab")) {
			wait(Constants.WAIT_15_SECOND);
			myClick("Pre-OrderTab.SpanName");
			wait(Constants.WAIT_15_SECOND);
			mySendKey("Pre-OrderTab.Po.Input", po);
			wait(Constants.WAIT_5_SECOND);
			myClick("Pre-OrderTab.ProcessStatus.Button");
			wait(Constants.WAIT_2_SECOND);
			myClick("Pre-OrderTab.ProcessStatus.SelectAll");
			wait(Constants.WAIT_2_SECOND);
			myClick("Pre-OrderTab.Background");
			wait(Constants.WAIT_1_SECOND);
			checkExist("Pre-OrderTab.Filter.Button");
			clickFilterButtonInPre_OrderTab();
			status = getText("Pre-OrderTab.TableResult.Status");
			compareTextFullReport(status, Constants.CONFIRMED);
		}

		if (isRequired("Submited Tab")
				&& Constants.CONFIRMED.equalsIgnoreCase(status)) {
			myClick("SubmitedTab.SpanName");
			wait(Constants.WAIT_2_SECOND);
			mySendKey("SubmitedTab.Po.Input", po);
			wait(Constants.WAIT_1_SECOND);
			checkExist("SubmitedTab.Filter.Button");
			for (int i = 1; i <= 10; i++) {
				wait(Constants.WAIT_2_SECOND);
				myClick("SubmitedTab.Filter.Button");
				wait(Constants.WAIT_5_SECOND);
				if (po.equalsIgnoreCase(getText("SubmitedTab.TableResult.PO"))) {
					break;
				}
				LOGGER.info("WAITING 30 SECONDS FOR MEDIA PULSE BACK DATA FOR DB");
				wait(Constants.WAIT_30_SECOND);
			}
			compareTextFullReport(getText("SubmitedTab.TableResult.PO"), po);
		}
		LOGGER.info("Finish check submited order in Pre Order Tab and Submited Tab !");
	}

	@KeywordInfo(Description = "Check submit order in Media pulse", Priority = CRI_SCENARIO)
	public void checkMediaPulse() {
		LOGGER.info("Check submit order in Media pulse !");
		String choose = getDataText("Select Sourse");
		if (choose.contains(Constants.MISSING)
				|| choose.contains(Constants.PRE_ORDER)) {
			String mpOrderIdIngest = listOfMediaOrderDetail.get(
					TWO_ROW_MP_ORDER_ID_INGEST_ORDER).getMpOrderId();
			String mpOrderIdDelivery = listOfMediaOrderDetail.get(
					TWO_ROW_MP_ORDER_ID_DELIVERY_ORDER).getMpOrderId();

			LOGGER.info("LISTOFMEDIAORDERDETAIL:" + listOfMediaOrderDetail);
			checkRowOrderIngest(mpOrderIdIngest, mpOrderIdDelivery);
			checkRowOrderDelivery(null, mpOrderIdDelivery);
		}
		// else if (choose.contains(Constants.INGEST_ONLY)) {
		// String mpOrderIdIngest = listOfMediaOrderDetail.get(
		// TWO_ROW_MP_ORDER_ID_INGEST_ORDER).getMpOrderId();
		// checkRowOrderIngest(mpOrderIdIngest, mpOrderIdDelivery);
		// }
		else {
			String mpOrderIdDelivery = listOfMediaOrderDetail.get(
					ONE_ROW_MP_ORDER_ID_DELIVERY_ORDER).getMpOrderId();

			LOGGER.info("LISTOFMEDIAORDERDETAIL:" + listOfMediaOrderDetail);
			checkRowOrderDelivery(null, mpOrderIdDelivery);
		}
	}

	@KeywordInfo(Description = "Check Data After Submit In DB", Priority = CRI_SCENARIO)
	public void checkDataAfterSubmitInDB() {
		LOGGER.info("Check Data After Submit In DB");
		checkDataAfterSubmitOrder();
		boolean check = false;
		for (int i = 1; i <= 5; i++) {
			wait(Constants.WAIT_5_SECOND);
			listOfMediaOrderDetail = mpOrderService
					.findOneMpOrderDetailByPo(getDataText("Check Mp Order By Po")
							+ numberGenerate);
			if (listOfMediaOrderDetail.size() > 0) {
				check = true;
				break;
			}
		}
		if (!check) {
			myAssertThat(false, "NOT FIND " + po
					+ " ON TABLE MP_ORDER_DETAIL IN DATABASE.");
		}
		// Check MpOrder Receiver By Media Order Id
		MediaOrderDto mediaOrderDto = mediaOrderService
				.findOne(getDataText("Check Mp Order Receiver By Media Order Id")
						+ numberGenerate);
		if (!mpOrderService.findOneMpOrderReceiverByMediaOrderId(mediaOrderDto
				.getId())) {
			myAssertThat(false, "NOT FIND " + po
					+ " ON TABLE MP_ORDER_RECEIVER IN DATABASE.");
		}
	}

	@KeywordInfo(Description = "Close driver")
	public void closeWebDriver() {
		wait(Constants.WAIT_1_SECOND);
		closeDriver();
	}

	private List<String> getListRecipientName() {
		List<RecipientDto> listOfRecipientFromDB = new ArrayList<RecipientDto>();
		listOfRecipientFromDB = recipientService.findAllRecipient();
		List<String> listOfNameRecipientFromDB = new ArrayList<String>();

		for (RecipientDto recipient : listOfRecipientFromDB) {
			listOfNameRecipientFromDB.add(recipient.getName());
		}
		return listOfNameRecipientFromDB;
	}

	private void compareListProjectAndSelectProject() {
		myClick("OrderDetails.Project.Dropdown");
		List<WebElement> listOfProjectFromUI = new ArrayList<WebElement>();
		listOfProjectFromUI = getElements("OrderDetails.Project.Span.Dropdown");

		List<String> listOfNameProjectFromUI = new ArrayList<String>();
		if (listOfProjectFromUI != null) {
			for (int i = 1; i < listOfProjectFromUI.size(); i++) {
				listOfNameProjectFromUI.add(listOfProjectFromUI.get(i)
						.getText());
			}
		}
		listOfProjectFromDB = projectService.findAllProject();

		List<String> listOfNameProjectFromDB = new ArrayList<String>();
		for (ProjectDto project : listOfProjectFromDB) {
			listOfNameProjectFromDB.add(project.getName());
		}
		checkListEqual(listOfNameProjectFromUI, listOfNameProjectFromDB);

		if (isRequired("Select Project In Details Tab")) {
			myClick("OrderDetails.Project.Dropdown");
			wait(Constants.WAIT_1_SECOND);
			myClick(buildObjPathByFieldNames(
					"OrderDetails.Project.Span.Dropdown.Select",
					"Select element of Project"));
			myClearAndInput("OrderDetails.DueDate.DatePick", dateCompare);
			myClearAndInput("OrderDetails.StartDate.DatePick", dateCompare);
		}
	}

	public void checkDataAfterSubmitOrder() {
		checkDataInOrderDetails();
		if (isRequired("Add Titles button")) {
			checkDataInSelectTitle();
		}
		if (isRequired("Pre-Oder Information Tab")) {
			checkDataInListOfSource();
		}
	}

	public void checkValueFilterComponentOnPreferencesTab() {
		if (isRequired("Asset Type Preferences tab")) {
			if (isExisted("Preferences.Combobox_AssetType", 30)) {
				wait(Constants.WAIT_1_SECOND);
				compareTextFullReport(
						getText("Preferences.Combobox_AssetType"),
						getDataText("Asset Type Preferences tab"));
			}
		}
		wait(Constants.WAIT_1_SECOND);
		if (isRequired("Edit Version Preferences tab")) {
			wait(Constants.WAIT_1_SECOND);
			compareTextFullReport(getText("Preferences.Combobox_EditVersion"),
					getDataText("Edit Version Preferences tab"));
		}
		wait(Constants.WAIT_1_SECOND);
		if (isRequired("Process Type Preferences tab")) {
			wait(Constants.WAIT_1_SECOND);
			compareTextFullReport(getText("Preferences.Combobox_ProcessType"),
					getDataText("Process Type Preferences tab"));
		}
		wait(Constants.WAIT_1_SECOND);
		if (isRequired("Matte Style Preferences tab")) {
			wait(Constants.WAIT_1_SECOND);
			compareTextFullReport(getText("Preferences.Combobox_MatteType"),
					getDataText("Matte Style Preferences tab"));
		}
		wait(Constants.WAIT_1_SECOND);
		if (isRequired("Texted Type Preferences tab")) {
			wait(Constants.WAIT_1_SECOND);
			compareTextFullReport(getText("Preferences.Combobox_TextedType"),
					getDataText("Texted Type Preferences tab"));
		}
		wait(Constants.WAIT_1_SECOND);
		if (isRequired("Content Type Preferences tab")) {
			wait(Constants.WAIT_1_SECOND);
			compareTextFullReport(getText("Preferences.Combobox_ContentType"),
					getDataText("Content Type Preferences tab"));
		}
	}

	private void addNewTitle() {
		myClick("SelectTitle.AddTitles.Button");
		wait(Constants.WAIT_5_SECOND);
		ipTitleId = getDataText("Input Ip Title Id In Add Title")
				+ numberGenerate;
		ipTitle = getDataText("Input Ip Title In Add Title") + numberGenerate;
		LOGGER.info("IP TITLE ID: " + ipTitleId);
		LOGGER.info("IP TITLE: " + ipTitle);
		mySendKey("SelectTitle.AddTitles.IpTitleId.Input", ipTitleId);
		wait(Constants.WAIT_1_SECOND);
		mySendKey("SelectTitle.AddTitles.IpTitle.Input", ipTitle);
		wait(Constants.WAIT_2_SECOND);
		myClick(buildObjPathByFieldNames("SelectTitle.AddTitles.Type.Select",
				"Input Type In Add Title"));
		wait(Constants.WAIT_1_SECOND);
		mySendKey("SelectTitle.AddTitles.PrimaryRelease.Input",
				getDataText("Input Primary Release In Add Title")
						+ numberGenerate);
		wait(Constants.WAIT_1_SECOND);
		mySendKey("SelectTitle.AddTitles.Secondary.Input",
				getDataText("Input Secondary Release In Add Title")
						+ numberGenerate);
		wait(Constants.WAIT_1_SECOND);
		myClick(buildObjPathByFieldNames("SelectTitle.AddTitles.Level.Select",
				"Input Level In Add Title"));
		wait(Constants.WAIT_1_SECOND);
		myClick("SelectTitle.AddTitle.Save.Button");
		wait(Constants.WAIT_5_SECOND);
		myClick("SelectTitle.ResultIntable.CheckBox");
	}

	public void mockTitle() {
		SubmitOrder order = new SubmitOrder();
		MockDataForSubmitOrder mockDataForSubmitOrder = new MockDataForSubmitOrder();
		switch (getDataText("Mock Data")) {
		case Constants.ON_ORDER:
			mockDataForSubmitOrder.modifyDataMockForSaveOrSubmitOrder(
					Constants.MOCK_ANALYZE_SUBMIT_ORDER_FILE, true, true);
			order.callApiSubmitOrder();
			break;
		case Constants.ON_ORDER_MISSING:
			mockDataForSubmitOrder.modifyDataMockForSaveOrSubmitOrder(
					Constants.MOCK_ANALYZE_SUBMIT_ON_ODER_MISSING_FILE, true,
					false);
			order.callApiSubmitOrder();
			break;
		default:
			mockDataForSubmitOrder.modifyDataMockForSaveOrSubmitOrder(
					Constants.MOCK_ANALYZE_SAVE_ORDER_FILE, false, false);
			order.callApiSaveOrder();
		}
	}

	public void checkBlankSoure() {
		WebDriver driver = Global.webDriver;
		WebElement element;
		String xpath = "((//div[@class='ui-grid-canvas'])[6]//div[contains(@class,'invalid-row')])";
		String xpathNew;
		for (int i = 7; i < 10; i++) {
			xpathNew = xpath + "[" + i + "]";
			if (i == 11) {
				element = driver.findElement(By.xpath(xpathNew));
				compareTextFullReport(element.getAttribute("value"), "EMASTER");
			} else {
				element = driver.findElement(By.xpath(xpathNew));
				compareTextFullReport(element.getAttribute("value"), null);
			}
		}
	}

	private void checkDataInOrderDetails() {
		boolean check;
		MediaOrderDto mediaOrderDto = mediaOrderService
				.findOne(getDataText("Check Media Order By Po")
						+ numberGenerate);
		LOGGER.info("MEDIA ORDER DTO: " + mediaOrderDto.toString());
		LOGGER.info("PROJECT ID MEDIA ORDER GET FROM DB: "
				+ mediaOrderDto.getProjectId());
		List<Long> projectIds = new ArrayList<Long>();

		for (ProjectDto project : listOfProjectFromDB) {
			projectIds.add(project.getId());
		}
		check = projectIds.contains(mediaOrderDto.getProjectId());
		myAssertThat(check, "PROJECT NOT EQUAL WITH DATABASE.");
		check = false;
		for (ProjectDto project : listOfProjectFromDB) {
			if (getDataText("Check Project")
					.equalsIgnoreCase(project.getName())) {
				check = true;
				break;
			}
		}
		myAssertThat(check, "PROJECT NOT EQUAL WITH DATABASE.");
		compareTextFullReport(mediaOrderDto.getType(),
				getDataText("Check Type"));
		compareTextFullReport(mediaOrderDto.getOrderName(),
				getDataText("Check Order Name") + numberGenerate);
		compareTextFullReport(mediaOrderDto.getPo(), getDataText("Check Po")
				+ numberGenerate);
		compareTextFullReport(mediaOrderDto.getNote().trim(),
				getDataText("Check Note") + numberGenerate);
		compareTextFullReport(mediaOrderDto.getRecipient(),
				getDataText("Check Recipient"));
	}

	private void checkDataInSelectTitle() {
		TitleDto titleDto = titleService
				.findOne(getDataText("Check Ip Title Id In Add Title")
						+ numberGenerate);
		compareTextFullReport(titleDto.getIpTitleId(),
				getDataText("Check Ip Title Id In Add Title") + numberGenerate);
		compareTextFullReport(titleDto.getIpTitle(),
				getDataText("Check Ip Title In Add Title") + numberGenerate);
		compareTextFullReport(titleDto.getType(),
				getDataText("Check Type In Add Title"));
		compareTextFullReport(titleDto.getPrimaryRelease(),
				getDataText("Check Primary Release In Add Title")
						+ numberGenerate);
		compareTextFullReport(titleDto.getSecondaryRelease(),
				getDataText("Check Secondary Release In Add Title")
						+ numberGenerate);
		compareTextFullReport(String.valueOf(titleDto.getTitleLevel()),
				getDataText("Check Level In Add Title"));
	}

	private void checkDataInListOfSource() {
		SourceAssetService assetService = new SourceAssetService();
		SourceAsset asset = assetService
				.findOneBySourceBarcode(getDataText("Check Barcode In LOS Analyze Source")
						+ numberGenerate);
		compareTextFullReport(asset.getSourceMethod(),
				getDataText("Check Source Method In LOS Analyze Source"));
		compareTextFullReport(asset.getSourceType(),
				getDataText("Check Source Type In LOS Analyze Source"));
		compareTextFullReport(asset.getReleaseType(),
				getDataText("Check Release Type In LOS Analyze Source"));
		compareTextFullReport(asset.getAssetFrom(),
				getDataText("Check From In LOS Analyze Source")
						+ numberGenerate);
		compareTextFullReport(asset.getSourceBarcode(),
				getDataText("Check Barcode In LOS Analyze Source")
						+ numberGenerate);
		compareTextFullReport(String.valueOf(asset.getEtaAfter()),
				getDataText("Check ETA After In LOS Analyze Source"));
	}

	private void addNewRow() {
		myClick("Pre-Oder.Information.AddButton");
		wait(Constants.WAIT_1_SECOND);
		myClick("Pre-Oder.Information.CheckBox");
		wait(Constants.WAIT_1_SECOND);
		myClick("Pre-Oder.Information.SourceType");
		wait(Constants.WAIT_1_SECOND);
		myClick(buildObjPathByFieldNames(
				"Pre-Oder.Information.SourceType.Option",
				"Pre-Oder Select Source Type"));
		sourceType = getText("Pre-Oder.Information.SourceType.Option");
		wait(Constants.WAIT_1_SECOND);
		myClick("Pre-Oder.Information.ReleaseType");
		wait(Constants.WAIT_1_SECOND);
		myClick(buildObjPathByFieldNames(
				"Pre-Oder.Information.ReleaseType.Option",
				"Pre-Oder Select Release Type"));
		releaseType = getText("Pre-Oder.Information.ReleaseType.Option");
		wait(Constants.WAIT_1_SECOND);
		mySendKey("Pre-Oder.Information.From",
				getDataText("Pre-Oder Input From") + numberGenerate);
		wait(Constants.WAIT_1_SECOND);
		mySendKey("Pre-Oder.Information.Barcode",
				getDataText("Pre-Oder Input Barcode") + numberGenerate);
		wait(Constants.WAIT_1_SECOND);
		myClick("Pre-Oder.Information.ETA.CheckBox");
		wait(Constants.WAIT_1_SECOND);
		typeText("Pre-Oder.Information.ETA.Input", "Pre-Oder Input Data in ETA");
		wait(Constants.WAIT_1_SECOND);
		myClick("Pre-Oder.Information.Save");
		wait(Constants.WAIT_1_SECOND);
	}

	private void actionsInCCTab() {
		if (isRequired("Go to CC tab")) {
			wait(Constants.WAIT_1_SECOND);
			myClick("Analyze.Source.CC");
			wait(Constants.WAIT_1_SECOND);
			switch (getDataText("Select Check box in CC tab")) {
			case Constants.MISSING:
				myClick("Analyze.Source.CC.CheckBox.Row1");
				break;
			case Constants.ON_ORDER:
				myClick("Analyze.Source.CC.CheckBox.Row1");
				break;
			case Constants.NONE_ROW:
				myClick("Analyze.Source.CC.CheckBox.None");
				break;
			case Constants.AWAITING_INGEST:
				myClick("Analyze.Source.CC.CheckBox.Row1");
			default:
				break;
			}
			if (isRequired("Add Row In CC Tab")) {
				wait(Constants.WAIT_1_SECOND);
				myClick("Analyze.Source.CC.Status");
				addNewRow();
			}
			if (isRequired("Select status after check in CC tab")) {
				myClick("Analyze.Source.CC.Status");
				wait(Constants.WAIT_1_SECOND);
				myClick("Pre-Oder.Information.CheckBox");
				wait(Constants.WAIT_1_SECOND);
				myClick("Pre-Oder.Information.Save");
				wait(Constants.WAIT_1_SECOND);
			}
		}
	}

	private void actionsInVideoTab() {
		if (isRequired("Select check box in Video Tab")) {
			myClick("Analyze.Source.Video.CheckBox.Row1");
		}
		wait(Constants.WAIT_10_SECOND);
		if (Constants.PRE_ORDER.equalsIgnoreCase(getDataText("Mock Data"))) {
			if (Constants.MISSING
					.equalsIgnoreCase(getText("Analyze.Source.Video.Status"))) {
				myClick("Analyze.Source.Video.Status");
				wait(Constants.WAIT_1_SECOND);
				addNewRow();
			}
		}

		if (isRequired("Select status after check in Video Tab")) {
			wait(Constants.WAIT_5_SECOND);
			myClick("Analyze.Source.Video.Status.AfterSelect");
			wait(Constants.WAIT_1_SECOND);
		}
	}

	private void actionsInAudioTab() {
		if (isRequired("Go to Audio Tab")) {
			wait(Constants.WAIT_20_SECOND);
			myClick("Analyze.Source.Audio");
			wait(Constants.WAIT_1_SECOND);
			myClick("Analyze.Source.Audio.CheckBox");
			if (isRequired("Select status after check in Audio Tab")) {
				wait(Constants.WAIT_1_SECOND);
				myClick("Analyze.Source.Audio.Status1");
				wait(Constants.WAIT_1_SECOND);
				myClick("Pre-Oder.Information.CheckBox");
				wait(Constants.WAIT_1_SECOND);
				myClick("Pre-Oder.Information.Save");
				wait(Constants.WAIT_1_SECOND);
				myClick("Analyze.Source.Audio.Status2");
				wait(Constants.WAIT_1_SECOND);
				myClick("Pre-Oder.Information.CheckBox");
				wait(Constants.WAIT_1_SECOND);
				myClick("Pre-Oder.Information.Save");
			}

			if (isRequired("Add Row In Audio Tab")) {
				myClick("Analyze.Source.Audio.Status.AfterSelect");
				addNewRow();
				wait(Constants.WAIT_1_SECOND);
				myClick("Analyze.Source.Audio.Status.Missing.2");
				wait(Constants.WAIT_1_SECOND);
				myClick("Pre-Oder.Information.CheckBox");
				wait(Constants.WAIT_1_SECOND);
				myClick("Pre-Oder.Information.Save");
			}
		}
	}

	private void actionsInSubtitleTab() {
		if (isRequired("Go to SubTitle Tab")) {
			myClick("Analyze.Source.Subtitle");
			wait(Constants.WAIT_1_SECOND);
			myClick("Analyze.Source.Subtitle.CheckBox");
		}
	}

	private void compareValueInLOS() {
		if (isRequired("Compare value of data Los")) {
			wait(Constants.WAIT_4_SECOND);
			compareTextFullReport(getText("LOS.OrderName"), orderName);
			wait(Constants.WAIT_1_SECOND);
			compareTextFullReport(getText("LOS.SourceType"), sourceType);
			wait(Constants.WAIT_1_SECOND);
			compareTextFullReport(getText("LOS.ReleaseType"), releaseType);
			wait(Constants.WAIT_1_SECOND);
			compareTextFullReport(getText("LOS.From"),
					getDataText("Pre-Oder Input From") + numberGenerate);
			wait(Constants.WAIT_1_SECOND);
			compareTextFullReport(getText("LOS.EXTSourceBarcode"),
					getDataText("Pre-Oder Input Barcode") + numberGenerate);
			wait(Constants.WAIT_1_SECOND);
			String eta = getDataText("Pre-Oder Input Data in ETA")
					+ Constants.DAY_AFTER_ORDER_SUB_MISSION;
			compareTextFullReport(getText("LOS.ETA"), eta);
		}
	}

	private void clickSourceLinkGoToSSS() {
		if (isRequired("Click Source link")) {
			wait(Constants.WAIT_4_SECOND);
			myClick("LOS.LinkSSS");
			wait(Constants.WAIT_8_SECOND);
			if (isRequired("Select data on Standard Asset")) {
				myClick("Asset.Select_Standard");
				wait(Constants.WAIT_2_SECOND);
				myClick("Asset.Select_Standard.Option");
				myClick(buildObjPathByFieldNames(
						"SSS.Asset.Select_Standard.Option",
						"Select data on Standard Asset"));
			}
			scrollModalDown();
			if (isRequired("Select data on Container Aspect Ratio")) {
				wait(Constants.WAIT_2_SECOND);
				myClick("AssetVideo.Select_ContainerAspectRatio");
				wait(Constants.WAIT_2_SECOND);
				myClick("AssetVideo.Select_ContainerAspectRatio.Option");
				myClick(buildObjPathByFieldNames(
						"SSS.AssetVideo.Select_ContainerAspectRatio.Option",
						"Select data on Container Aspect Ratio"));
			}
			if (isRequired("Select data on Edit version")) {
				wait(Constants.WAIT_2_SECOND);
				myClick(buildObjPathByFieldNames(
						"EditVersion.Select_EditVersion.SelectedOption",
						"Select data on Edit version"));
				wait(Constants.WAIT_2_SECOND);
			}
			if (isRequired("Select data on Content Type")) {
				myClick(buildObjPathByFieldNames(
						"Asset.Select_ContentType.SelectedOption",
						"Select data on Content Type"));
			}

		}
	}

	private void addNewRowInLOS() {
		wait(Constants.WAIT_1_SECOND);
		myClick("LOS.AddAnotherSource");
		wait(Constants.WAIT_1_SECOND);
		myClick("Pre-Oder.Information.SourceType");
		wait(Constants.WAIT_1_SECOND);
		myClick(buildObjPathByFieldNames(
				"Pre-Oder.Information.SourceType.Option",
				"Pre-Oder Select Source Type Los"));
		wait(Constants.WAIT_1_SECOND);
		myClick("Pre-Oder.Information.ReleaseType");
		wait(Constants.WAIT_1_SECOND);
		myClick(buildObjPathByFieldNames(
				"Pre-Oder.Information.ReleaseType.Option",
				"Pre-Oder Select Release Type Los"));
		wait(Constants.WAIT_1_SECOND);
		mySendKey("Pre-Oder.Information.From",
				getDataText("Pre-Oder Input From Los") + numberGenerate);
		wait(Constants.WAIT_1_SECOND);
		mySendKey("Pre-Oder.Information.Barcode",
				getDataText("Pre-Oder Input Barcode Los") + numberGenerate);
		wait(Constants.WAIT_1_SECOND);
		myClick("Pre-Oder.Information.ETA.CheckBox");
		wait(Constants.WAIT_1_SECOND);
		typeText("Pre-Oder.Information.ETA.Input",
				"Pre-Oder Input Data in ETA Los");
		wait(Constants.WAIT_1_SECOND);
		myClick("Pre-Oder.Information.Save");
		wait(Constants.WAIT_2_SECOND);
	}

	private void clickFilterButtonInPre_OrderTab() {
		for (int i = 1; i <= 10; i++) {
			myClick("Pre-OrderTab.Filter.Button");
			wait(Constants.WAIT_2_SECOND);
			if (Constants.CONFIRMED
					.equalsIgnoreCase(getText("Pre-OrderTab.TableResult.Status"))) {
				break;
			}
			LOGGER.info("WAITING 30 SECONDS FOR MEDIA PULSE BACK DATA FOR DB");
			wait(Constants.WAIT_30_SECOND);
		}
	}

	@SuppressWarnings("unused")
	private void checkResultInMP() {
		compareTextFullReport(
				getText(buildObjPathByFieldNames("MP.Home.ResultAfterSearch",
						"Check Result Search In MP")), po);

		String sourceInMediaPulse = getDataText("Select Sourse");
		if (sourceInMediaPulse.equalsIgnoreCase(Constants.AWAITING_INGEST)
				|| sourceInMediaPulse.equalsIgnoreCase(Constants.ON_ORDER)
				|| sourceInMediaPulse.equalsIgnoreCase(Constants.INGESTED)
				|| sourceInMediaPulse
						.equalsIgnoreCase(Constants.AWAITING_INGEST_ON_ORDER)
				|| sourceInMediaPulse
						.equalsIgnoreCase(Constants.INGESTED_ON_ORDER)) {
			checkNotExist("MP.Home.ResultNoteFull.Table");
			checkExist("MP.Home.ResultNoteEmpty.Table");

		} else if (sourceInMediaPulse.equalsIgnoreCase(Constants.MISSING)
				|| sourceInMediaPulse
						.equalsIgnoreCase(Constants.BLANK_INGEST_ONLY)
				|| sourceInMediaPulse.equalsIgnoreCase(Constants.PRE_ORDER)
				|| sourceInMediaPulse
						.equalsIgnoreCase(Constants.ON_ORDER_MISSING)
				|| sourceInMediaPulse
						.equalsIgnoreCase(Constants.INGESTED_MISSING)) {
			checkExist("MP.Home.ResultNoteFull.Table");
			checkExist("MP.Home.ResultNoteEmpty.Table");
		}
	}

	private void checkRowOrderIngest(String mpOrderIdIngest,
			String mpOrderIdDelivery) {
		checkOrderDetailInMP("Check Status Ingest",
				"Check Service Vendo Ingest", "Check Receipient Ingest",
				mpOrderIdIngest);
		String note = GenerateString.readFileDataGetFromMP("tdc:note_no_text",
				5);
		compareTextContains(note, getDataText("Check Video Ingest"));
		compareTextContains(note, getDataText("Check Audio 1 Ingest"));
		compareTextContains(note, getDataText("Check Audio 2 Ingest"));
		compareTextContains(note, getDataText("Check CC Ingest"));
		checkServiceInformation("Check Service Description Ingest",
				"Check Servive Row 1 Ingest", "Check Servive Row 2 Ingest",
				"Check Service Status Desciption Ingest 1",
				"Check Service Status Desciption Ingest 2");
		checkLinkWONoSeq(mpOrderIdDelivery);
	}

	private void checkRowOrderDelivery(String mpOrderIdIngest,
			String mpOrderIdDelivery) {
		checkOrderDetailInMP("Check Status Delivery",
				"Check Service Vendo Delivery", "Check Receipient Delivery",
				mpOrderIdDelivery);
		checkServiceInformation("Check Service Description Delivery",
				"Check Servive Row 1 Delivery", "Check Servive Row 2 Delivery",
				"Check Service Status Desciption Delivery Row 1",
				"Check Service Status Desciption Delivery Row 2");
		if (mpOrderIdIngest != null) {
			MediaOrderDetailDto detailDto = mpOrderService
					.findOneMpOrderDetailByMpOrderId(mpOrderIdDelivery);
			String[] listOfLink = detailDto.getLink().toString().split(",");
			int sizeListOfLink = listOfLink.length;
			switch (sizeListOfLink) {
			case 1:
				checkLinkWONoSeq(mpOrderIdIngest);
				break;
			case 2:
				checkLinkWONoSeqTwoOrderId(listOfLink);
				break;
			default:
				LOGGER.info("IGNORE CHECK LINK WO NO SEQ!!!");
				break;
			}
		}
	}

	private void checkServiceInformation(String serviceDesingestExcel,
			String serviceNameRow1Excel, String serviceNameRow2Excel,
			String serviceStatusRow1Exel, String serviceStatusRow2Exel) {
		String serviceTemplate = GenerateString.readFileDataGetFromMP(
				"tdc:service_desc", 0);
		compareTextFullReport(serviceTemplate,
				getDataText(serviceDesingestExcel));
		String serviceNameRow1 = GenerateString.readFileDataGetFromMP(
				"tdc:service_desc", 1);
		compareTextFullReport(serviceNameRow1,
				getDataText(serviceNameRow1Excel));
		String serviceNameRow2 = GenerateString.readFileDataGetFromMP(
				"tdc:service_desc", 3);
		compareTextFullReport(serviceNameRow2,
				getDataText(serviceNameRow2Excel));
		String serviceStatusRow1 = GenerateString.readFileDataGetFromMP(
				"tdc:service_status_desc", 0);
		compareTextFullReport(serviceStatusRow1,
				getDataText(serviceStatusRow1Exel));
		String serviceStatusRow2 = GenerateString.readFileDataGetFromMP(
				"tdc:service_status_desc", 1);
		compareTextFullReport(serviceStatusRow2,
				getDataText(serviceStatusRow2Exel));
	}

	private void checkLinkWONoSeq(String mpOrderIdDelivery) {
		String linkedWONoSeq1Ingest = GenerateString.readFileDataGetFromMP(
				"tdc:wo_no_seq", 5);
		compareTextFullReport(linkedWONoSeq1Ingest, mpOrderIdDelivery);
		String linkedWONoSeq2Ingest = GenerateString.readFileDataGetFromMP(
				"tdc:wo_no_seq", 7);
		compareTextFullReport(linkedWONoSeq2Ingest, mpOrderIdDelivery);
	}

	private void checkLinkWONoSeqTwoOrderId(String[] listOfLink) {
		String linkedWONoSeq1Ingest = GenerateString.readFileDataGetFromMP(
				"tdc:wo_no_seq", 5);
		compareTextFullReport(linkedWONoSeq1Ingest,
				listOfLink[CHECK_LINK_WO_NOSEQ_FIRST_BY_UI].trim());
		String linkedWONoSeq2Ingest = GenerateString.readFileDataGetFromMP(
				"tdc:wo_no_seq", 7);
		compareTextFullReport(linkedWONoSeq2Ingest,
				listOfLink[CHECK_LINK_WO_NOSEQ_FIRST_BY_UI].trim());
		String linkedWONoSeq3Ingest = GenerateString.readFileDataGetFromMP(
				"tdc:wo_no_seq", 9);
		compareTextFullReport(linkedWONoSeq3Ingest,
				listOfLink[CHECK_LINK_WO_NOSEQ_SECOND_BY_UI].trim());
		String linkedWONoSeq4Ingest = GenerateString.readFileDataGetFromMP(
				"tdc:wo_no_seq", 11);
		compareTextFullReport(linkedWONoSeq4Ingest,
				listOfLink[CHECK_LINK_WO_NOSEQ_SECOND_BY_UI].trim());
	}

	private void checkOrderDetailInMP(String statusExcel,
			String serviceVendoExcel, String receipientExcel, String mpOrderId) {
		SOAPClientSAAJ.writeDataToFileXmlMP(mpOrderId);
		String status = null;
		switch (getDataText("Select Sourse")) {
		case Constants.AWAITING_INGEST:
			status = GenerateString.readFileDataGetFromMP("tdc:phase_desc", 0);
			break;
		case Constants.INGESTED:
			status = GenerateString.readFileDataGetFromMP("tdc:phase_desc", 0);
			break;
		case Constants.AWAITING_INGEST_INGESTED:
			status = GenerateString.readFileDataGetFromMP("tdc:phase_desc", 0);
			break;
		default:
			status = GenerateString.readFileDataGetFromMP("tdc:phase_desc", 2);
			break;
		}
		if (TEXT_PO_CASE_9.equalsIgnoreCase(getDataText("Input data PO"))) {
			if ("Check Status Delivery".equals(statusExcel)) {
				status = GenerateString.readFileDataGetFromMP("tdc:phase_desc",
						4);
			}
		}
		compareTextFullReport(getDataText(statusExcel), status);
		String serviceVendor = GenerateString.readFileDataGetFromMP(
				"tdc:vend_id", 0);
		compareTextFullReport(getDataText(serviceVendoExcel), serviceVendor);
		String recipient = GenerateString.readFileDataGetFromMP("tdc:list_id",
				5);
		compareTextFullReport(getDataText(receipientExcel), recipient);
		String blankRow = GenerateString.readFileDataGetFromMP("tdc:title", 0);
		if (isRequired("Check Blank Row In MP")) {
			if ("".equals(getDataText("Check Ip Title In Add Title"))) {
				compareTextFullReport(blankRow, MockDataForSubmitOrder.ipTitle);
			} else {
				compareTextFullReport(blankRow,
						getDataText("Check Ip Title In Add Title")
								+ numberGenerate);
			}
		}
	}
}
