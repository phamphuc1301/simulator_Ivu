package com.vubiquity.intellivu.simulator.dete.analyze.service;

import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.vubiquity.intellivu.simulator.dete.analyze.dto.SourceSelectionByAsset;
import com.vubiquity.intellivu.simulator.dete.analyze.dto.SourceSelectionByAssetRoot;
import com.vubiquity.intellivu.simulator.dete.analyze.repository.SourceSelectionByAssetRepository;

@RestController
public class AnalyzeSourceService {

    private static final String UNDERLINE_KEY = "_";
    private static final String COMMA_KEY = ",";
    
    @Autowired
    private SourceSelectionByAssetRepository sourceSelectionByAssetRepository;
    
    @RequestMapping(method = RequestMethod.GET, value = "/sourceSelectionAnalysis")
    @ResponseBody
    public SourceSelectionByAssetRoot analyzeSourcesMock(@RequestParam(value = "assetIds") String assetIds, @RequestParam(value = "recipientId") String recipientId,
            @RequestParam(value = "tenant") String tenant) {
        String[] assetIdArrays = assetIds.split(COMMA_KEY);
        if (assetIdArrays == null || assetIdArrays.length == 0) {
            return null;
        }
        
        List<SourceSelectionByAsset> sourceSelectionByAssets = new ArrayList<>();
        for (String assetId: assetIdArrays) {
            SourceSelectionByAsset sourceSelectionByAsset = sourceSelectionByAssetRepository.findOne(buildKey(assetId, tenant, recipientId));
            if (sourceSelectionByAsset != null) {
                sourceSelectionByAssets.add(sourceSelectionByAsset);
            }
        }
        return new SourceSelectionByAssetRoot(sourceSelectionByAssets);
    }

    @RequestMapping(method = RequestMethod.POST, value = "/addSourceSelectionByAsset")
    @ResponseBody
    public ResponseEntity<Void> addSourceSelectionByAsset(@RequestBody @NotNull SourceSelectionByAsset sourceSelectionByAsset, @RequestParam(value = "recipientId") @NotNull String recipientId,
            @RequestParam(value = "tenant") @NotNull String tenant) {
        String assetId = sourceSelectionByAsset.getAssetId();
        if (StringUtils.isBlank(assetId)) {
            return ResponseEntity.badRequest().build();
        }
        
        sourceSelectionByAsset.setId(buildKey(assetId, tenant, recipientId));
        sourceSelectionByAssetRepository.save(sourceSelectionByAsset);

        return ResponseEntity.ok().build();
    }

    @ExceptionHandler
    public ResponseEntity<Void> handleInvalidTopTalentDataException(MethodArgumentNotValidException methodArgumentNotValidException) {
        return ResponseEntity.badRequest().build();
    }
    
    private String buildKey(String assetId, String tenant, String recipientId) {
        StringBuilder sb = new StringBuilder();
        sb.append(assetId);
        sb.append(UNDERLINE_KEY);
        sb.append(tenant);
        sb.append(UNDERLINE_KEY);
        sb.append(recipientId);
        return sb.toString();
    }
}
