package com.vubiquity.intellivu.simulator.dete.analyze.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Component {
	private int ranking;
	private boolean result;
	private List<PreferenceSelection> preferenceSelection;

	public int getRanking() {
		return ranking;
	}

	public void setRanking(int ranking) {
		this.ranking = ranking;
	}

	public boolean isResult() {
		return result;
	}

	public void setResult(boolean result) {
		this.result = result;
	}

	public List<PreferenceSelection> getPreferenceSelection() {
		return preferenceSelection;
	}

	public void setPreferenceSelection(List<PreferenceSelection> preferenceSelection) {
		this.preferenceSelection = preferenceSelection;
	}

}
