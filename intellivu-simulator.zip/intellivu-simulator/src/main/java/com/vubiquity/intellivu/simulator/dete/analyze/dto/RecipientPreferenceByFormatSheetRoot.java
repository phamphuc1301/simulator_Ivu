package com.vubiquity.intellivu.simulator.dete.analyze.dto;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
@Document(collection = "recipient_preference_by_format_sheet_root")
public class RecipientPreferenceByFormatSheetRoot {

    @JsonIgnore
    @Id
    private String id;// key = tenant_recipientId

    List<RecipientPreferenceByFormatSheet> recipientPreferenceByFormatSheet;

    public List<RecipientPreferenceByFormatSheet> getRecipientPreferenceByFormatSheet() {
        return recipientPreferenceByFormatSheet;
    }

    public void setRecipientPreferenceByFormatSheet(List<RecipientPreferenceByFormatSheet> recipientPreferenceByFormatSheet) {
        this.recipientPreferenceByFormatSheet = recipientPreferenceByFormatSheet;
    }

    public RecipientPreferenceByFormatSheetRoot(List<RecipientPreferenceByFormatSheet> recipientPreferenceByFormatSheet) {
        super();
        this.recipientPreferenceByFormatSheet = recipientPreferenceByFormatSheet;
    }

    public RecipientPreferenceByFormatSheetRoot() {
        super();
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

}
