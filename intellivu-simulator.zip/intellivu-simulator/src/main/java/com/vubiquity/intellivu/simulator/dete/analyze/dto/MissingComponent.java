package com.vubiquity.intellivu.simulator.dete.analyze.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class MissingComponent {
	private int ranking;
	private boolean result;
	private List<PreferenceSelection> preference;

	public int getRanking() {
		return ranking;
	}

	public void setRanking(int ranking) {
		this.ranking = ranking;
	}

	public boolean isResult() {
		return result;
	}

	public void setResult(boolean result) {
		this.result = result;
	}

	public List<PreferenceSelection> getPreference() {
		return preference;
	}

	public void setPreference(List<PreferenceSelection> preference) {
		this.preference = preference;
	}



}
