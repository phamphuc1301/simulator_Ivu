package com.vubiquity.intellivu.simulator.dete.analyze.repository;



import org.springframework.data.mongodb.repository.MongoRepository;

import com.vubiquity.intellivu.simulator.dete.analyze.dto.SourceSelectionByAsset;

public interface SourceSelectionByAssetRepository extends MongoRepository<SourceSelectionByAsset, String> {

}
