package com.vubiquity.intellivu.simulator.adoniss.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AAPIGetMediaManagerProviderPackageTierResult {
    private String finance_codec;

    private String mediaManager;

    private String c_codecs;

    private String c_contentpackage;

    private String c_contentparentcompany;

    private String c_contentprovideronDST;

    private String c_contenttier;

    private String c_video_format;

    private String dt_activated_package;

    private String dt_activated_provider;

    private String dt_activated_tier;

    private String dt_deactivated_package;

    private String dt_deactivated_provider;

    private String dt_deactivated_tier;

    private long i_contenttierhrs;

    private Long id_adonissuser;

    private Long id_adonissuserfunction_adonissuser;

    private long id_contentpackages;

    private long id_contentparentcompany;

    private long id_contentprovider;

    private long id_contenttiers;

    private Long id_contenttiersparent;

    public String getFinance_codec() {
        return finance_codec;
    }

    public void setFinance_codec(String finance_codec) {
        this.finance_codec = finance_codec;
    }

    public String getMediaManager() {
        return mediaManager;
    }

    public void setMediaManager(String mediaManager) {
        this.mediaManager = mediaManager;
    }

    public String getC_codecs() {
        return c_codecs;
    }

    public void setC_codecs(String c_codecs) {
        this.c_codecs = c_codecs;
    }

    public String getC_contentpackage() {
        return c_contentpackage;
    }

    public void setC_contentpackage(String c_contentpackage) {
        this.c_contentpackage = c_contentpackage;
    }

    public String getC_contentparentcompany() {
        return c_contentparentcompany;
    }

    public void setC_contentparentcompany(String c_contentparentcompany) {
        this.c_contentparentcompany = c_contentparentcompany;
    }

    public String getC_contentprovideronDST() {
        return c_contentprovideronDST;
    }

    public void setC_contentprovideronDST(String c_contentprovideronDST) {
        this.c_contentprovideronDST = c_contentprovideronDST;
    }

    public String getC_contenttier() {
        return c_contenttier;
    }

    public void setC_contenttier(String c_contenttier) {
        this.c_contenttier = c_contenttier;
    }

    public String getC_video_format() {
        return c_video_format;
    }

    public void setC_video_format(String c_video_format) {
        this.c_video_format = c_video_format;
    }

    public String getDt_activated_package() {
        return dt_activated_package;
    }

    public void setDt_activated_package(String dt_activated_package) {
        this.dt_activated_package = dt_activated_package;
    }

    public String getDt_activated_provider() {
        return dt_activated_provider;
    }

    public void setDt_activated_provider(String dt_activated_provider) {
        this.dt_activated_provider = dt_activated_provider;
    }

    public String getDt_activated_tier() {
        return dt_activated_tier;
    }

    public void setDt_activated_tier(String dt_activated_tier) {
        this.dt_activated_tier = dt_activated_tier;
    }

    public String getDt_deactivated_package() {
        return dt_deactivated_package;
    }

    public void setDt_deactivated_package(String dt_deactivated_package) {
        this.dt_deactivated_package = dt_deactivated_package;
    }

    public String getDt_deactivated_provider() {
        return dt_deactivated_provider;
    }

    public void setDt_deactivated_provider(String dt_deactivated_provider) {
        this.dt_deactivated_provider = dt_deactivated_provider;
    }

    public String getDt_deactivated_tier() {
        return dt_deactivated_tier;
    }

    public void setDt_deactivated_tier(String dt_deactivated_tier) {
        this.dt_deactivated_tier = dt_deactivated_tier;
    }

    public long getI_contenttierhrs() {
        return i_contenttierhrs;
    }

    public void setI_contenttierhrs(long i_contenttierhrs) {
        this.i_contenttierhrs = i_contenttierhrs;
    }

    public Long getId_adonissuser() {
        return id_adonissuser;
    }

    public void setId_adonissuser(Long id_adonissuser) {
        this.id_adonissuser = id_adonissuser;
    }

    public Long getId_adonissuserfunction_adonissuser() {
        return id_adonissuserfunction_adonissuser;
    }

    public void setId_adonissuserfunction_adonissuser(Long id_adonissuserfunction_adonissuser) {
        this.id_adonissuserfunction_adonissuser = id_adonissuserfunction_adonissuser;
    }

    public long getId_contentpackages() {
        return id_contentpackages;
    }

    public void setId_contentpackages(long id_contentpackages) {
        this.id_contentpackages = id_contentpackages;
    }

    public long getId_contentparentcompany() {
        return id_contentparentcompany;
    }

    public void setId_contentparentcompany(long id_contentparentcompany) {
        this.id_contentparentcompany = id_contentparentcompany;
    }

    public long getId_contentprovider() {
        return id_contentprovider;
    }

    public void setId_contentprovider(long id_contentprovider) {
        this.id_contentprovider = id_contentprovider;
    }

    public long getId_contenttiers() {
        return id_contenttiers;
    }

    public void setId_contenttiers(long id_contenttiers) {
        this.id_contenttiers = id_contenttiers;
    }

    public Long getId_contenttiersparent() {
        return id_contenttiersparent;
    }

    public void setId_contenttiersparent(Long id_contenttiersparent) {
        this.id_contenttiersparent = id_contenttiersparent;
    }

}
