package com.vubiquity.intellivu.simulator.dete.analyze.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class OutputParameters {
	private String standard;

	private String frameAspectRatio;

	public String getStandard() {
		return standard;
	}

	public void setStandard(String standard) {
		this.standard = standard;
	}

	public String getFrameAspectRatio() {
		return frameAspectRatio;
	}

	public void setFrameAspectRatio(String frameAspectRatio) {
		this.frameAspectRatio = frameAspectRatio;
	}

}
