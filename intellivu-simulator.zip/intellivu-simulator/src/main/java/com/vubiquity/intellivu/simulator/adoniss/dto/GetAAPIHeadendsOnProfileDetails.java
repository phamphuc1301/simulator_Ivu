package com.vubiquity.intellivu.simulator.adoniss.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class GetAAPIHeadendsOnProfileDetails {
    private String c_headendname;
    private String c_msoname;
    private String dt_activated;
    private String dt_deactivated;
    private long id_contenttiers;
    private long id_headends;
    private long id_msos;

    public String getC_headendname() {
        return c_headendname;
    }

    public void setC_headendname(String c_headendname) {
        this.c_headendname = c_headendname;
    }

    public String getC_msoname() {
        return c_msoname;
    }

    public void setC_msoname(String c_msoname) {
        this.c_msoname = c_msoname;
    }

    public String getDt_activated() {
        return dt_activated;
    }

    public void setDt_activated(String dt_activated) {
        this.dt_activated = dt_activated;
    }

    public String getDt_deactivated() {
        return dt_deactivated;
    }

    public void setDt_deactivated(String dt_deactivated) {
        this.dt_deactivated = dt_deactivated;
    }

    public long getId_contenttiers() {
        return id_contenttiers;
    }

    public void setId_contenttiers(long id_contenttiers) {
        this.id_contenttiers = id_contenttiers;
    }

    public long getId_headends() {
        return id_headends;
    }

    public void setId_headends(long id_headends) {
        this.id_headends = id_headends;
    }

    public long getId_msos() {
        return id_msos;
    }

    public void setId_msos(long id_msos) {
        this.id_msos = id_msos;
    }
}
