package com.vubiquity.intellivu.simulator.dete.analyze.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SourceSelectionByFormatSheet {
	private List<String> formatSheetId;

	private String outputTemplateName;

	private SourceSelectionByComponentType sourceSelectionByComponentType;

	public List<String> getFormatSheetId() {
		return formatSheetId;
	}

	public void setFormatSheetId(List<String> formatSheetId) {
		this.formatSheetId = formatSheetId;
	}

	public String getOutputTemplateName() {
		return outputTemplateName;
	}

	public void setOutputTemplateName(String outputTemplateName) {
		this.outputTemplateName = outputTemplateName;
	}

	public SourceSelectionByComponentType getSourceSelectionByComponentType() {
		return sourceSelectionByComponentType;
	}

	public void setSourceSelectionByComponentType(SourceSelectionByComponentType sourceSelectionByComponentType) {
		this.sourceSelectionByComponentType = sourceSelectionByComponentType;
	}

}
