package com.vubiquity.intellivu.simulator.adoniss.service;

import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.vubiquity.intellivu.simulator.adoniss.kafka.MessageSender;

@RestController
public class AdonissEventService {

    @Autowired
    private MessageSender messageSender;
    
    @RequestMapping(method = RequestMethod.POST, value = "/pushAdonissEvent")
    @ResponseBody
    public ResponseEntity<Void> pushAdonissEvent(@RequestBody @NotNull String adonissEvent) {
        messageSender.send(adonissEvent); 
        return ResponseEntity.ok().build();
    }
    
}
