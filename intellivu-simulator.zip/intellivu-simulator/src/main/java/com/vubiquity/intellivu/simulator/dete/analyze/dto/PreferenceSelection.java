package com.vubiquity.intellivu.simulator.dete.analyze.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PreferenceSelection {
	private String description;

	private SourceProperties sourceProperties;

	private OutputParameters outputParameters;

	private List<SelectedComponent> selectedComponents;

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public SourceProperties getSourceProperties() {
		return sourceProperties;
	}

	public void setSourceProperties(SourceProperties sourceProperties) {
		this.sourceProperties = sourceProperties;
	}

	public OutputParameters getOutputParameters() {
		return outputParameters;
	}

	public void setOutputParameters(OutputParameters outputParameters) {
		this.outputParameters = outputParameters;
	}

	public List<SelectedComponent> getSelectedComponents() {
		return selectedComponents;
	}

	public void setSelectedComponents(List<SelectedComponent> selectedComponents) {
		this.selectedComponents = selectedComponents;
	}

}
