package com.vubiquity.intellivu.simulator.dete.analyze.service;

import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.vubiquity.intellivu.simulator.dete.analyze.dto.RecipientPreferenceByFormatSheetRoot;
import com.vubiquity.intellivu.simulator.dete.analyze.repository.RecipientPreferenceByFormatSheetRootRepository;

@RestController
public class AnalyzeSourceNoneAssestService {

    private static final String UNDERLINE_KEY = "_";
    
    @Autowired
    private RecipientPreferenceByFormatSheetRootRepository recipientPreferenceByFormatSheetRootRepository;
    
    @RequestMapping(method = RequestMethod.GET, value = "/recipientPreferences")
    @ResponseBody
    public RecipientPreferenceByFormatSheetRoot analyzeSourcesMock(@RequestParam(value = "tenant") String tenant, @RequestParam(value = "recipientId") String recipientId) {
        return recipientPreferenceByFormatSheetRootRepository.findOne(buildKey(tenant, recipientId));
    }

    @RequestMapping(method = RequestMethod.POST, value = "/addRecipientPreferences")
    @ResponseBody
    public ResponseEntity<Void> addRecipientPreferenceByFormatSheetRoot(@RequestBody @NotNull RecipientPreferenceByFormatSheetRoot recipientPreferenceByFormatSheetRoot, @RequestParam(value = "recipientId") @NotNull String recipientId,
            @RequestParam(value = "tenant") @NotNull String tenant) {
        recipientPreferenceByFormatSheetRoot.setId(buildKey(tenant, recipientId));
        recipientPreferenceByFormatSheetRootRepository.save(recipientPreferenceByFormatSheetRoot);
        return ResponseEntity.ok().build();
    }

    @ExceptionHandler
    public ResponseEntity<Void> handleInvalidTopTalentDataException(MethodArgumentNotValidException methodArgumentNotValidException) {
        return ResponseEntity.badRequest().build();
    }
    
    private String buildKey(String tenant, String recipientId) {
        StringBuilder sb = new StringBuilder();
        sb.append(tenant);
        sb.append(UNDERLINE_KEY);
        sb.append(recipientId);
        return sb.toString();
    }
}
